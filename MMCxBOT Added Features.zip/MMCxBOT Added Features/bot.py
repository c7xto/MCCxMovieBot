import os
import logging
from pyrogram import Client
from dotenv import load_dotenv

# Load variables from your .env file
load_dotenv()

# Set up logging so we can see what's happening in the terminal
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Fetch tokens from .env
API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")

class AutoFilterBot(Client):
    def __init__(self):
        super().__init__(
            name="MCCxBot",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=BOT_TOKEN,
            # This line tells the bot to look inside the "plugins" folder for all our commands!
            plugins=dict(root="plugins"),
            # --- THE CONNECTION FIX ---
            sleep_threshold=60, # Tells the bot to stay awake longer
            max_concurrent_transmissions=3 # Keeps the ping to Telegram stable
        )

    async def start(self):
        await super().start()
        me = await self.get_me()
        logger.info(f"🚀 Bot started successfully as @{me.username}!")

    async def stop(self, *args):
        await super().stop()
        logger.info("🛑 Bot stopped.")

if __name__ == "__main__":
    # This runs the bot when you type 'python bot.py'
    bot = AutoFilterBot()
    bot.run()