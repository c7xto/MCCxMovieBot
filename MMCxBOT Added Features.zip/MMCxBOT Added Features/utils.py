import os
import asyncio
from pyrogram import Client, filters
from pyrogram.errors import UserNotParticipant
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.enums import ParseMode
from database.db import db

async def is_subscribed(client, message_or_callback):
    config = await db.get_config()
    fsub_channels = config.get("fsub_channels", [])
    
    if not fsub_channels:
        return True 
        
    user_id = message_or_callback.from_user.id
    
    for channel in fsub_channels:
        try:
            ch = int(channel) if str(channel).lstrip('-').isdigit() else str(channel)
            member = await client.get_chat_member(ch, user_id)
            
            if member.status.name in ["KICKED", "BANNED", "LEFT"]:
                return False
        except UserNotParticipant:
            return False
        except Exception as e:
            print(f"FSub Error on channel {channel}: {e}")
            continue
            
    return True

async def send_fsub_message(message):
    client = message._client 
    config = await db.get_config()
    fsub_channels = config.get("fsub_channels", [])
    
    buttons = []
    
    for i, channel in enumerate(fsub_channels, 1):
        try:
            ch_str = str(channel).strip()
            if ch_str.startswith("-100"):
                invite_link = await client.export_chat_invite_link(int(ch_str))
            elif ch_str.startswith("http"):
                invite_link = ch_str
            elif ch_str.startswith("@"):
                invite_link = f"https://t.me/{ch_str[1:]}"
            else:
                invite_link = f"https://t.me/{ch_str}"
                
            buttons.append([InlineKeyboardButton(f"📢 Join Channel {i}", url=invite_link)])
            
        except Exception as e:
            print(f"Could not generate link for {channel}: {e}")
            continue

    buttons.append([InlineKeyboardButton("✅ I've Joined — Check Now", callback_data="check_fsub_status")])
    markup = InlineKeyboardMarkup(buttons)
    
    text = (
        f"👋 <b>Hello {message.from_user.mention}!</b>\n\n"
        f"<blockquote>To use this bot, please join our channel(s) below.\n"
        f"Then tap <b>✅ I've Joined</b> to continue.</blockquote>"
    )
    
    await message.reply_text(text, reply_markup=markup, quote=True, parse_mode=ParseMode.HTML)