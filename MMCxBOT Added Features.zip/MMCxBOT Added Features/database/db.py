import os
import re
import logging
from bson.objectid import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient

logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        # 1. Load all 5 Cluster URIs
        self.uris = [
            os.getenv("DATABASE_URI"),
            os.getenv("DATABASE_URI_2"),
            os.getenv("DATABASE_URI_3"),
            os.getenv("DATABASE_URI_4"),
            os.getenv("DATABASE_URI_5")
        ]
        
        # 2. Initialize Clients and Collections
        self.clients = []
        self.dbs = []
        self.file_cols = []
        
        for i, uri in enumerate(self.uris):
            if uri:
                client = AsyncIOMotorClient(uri)
                self.clients.append(client)
                
                # The Database Name
                db_instance = client[f"MCCxBot_Cluster_{i+1}"]
                self.dbs.append(db_instance)
                
                # The File Collection
                self.file_cols.append(db_instance["movies"])

        # 3. Main System DB (Using Cluster 1 for Users and Settings)
        self.users_col = None
        self.banned_col = None
        self.config_col = None
        
        if self.dbs:
            self.main_db = self.dbs[0]
            self.users_col = self.main_db["users"]
            self.banned_col = self.main_db["banned_users"]
            self.config_col = self.main_db["bot_config"]

            self.cache_col = self.main_db["search_cache"]
            self.indexer_col = self.main_db["indexer_tasks"]

    # --- 🛡️ USER & BAN SYSTEM ---
    async def save_user(self, user_id, first_name):
        """Saves a new user and returns True if they are new (for logging)."""
        if self.users_col is None: return False
        user = await self.users_col.find_one({"_id": user_id})
        if not user:
            await self.users_col.insert_one({"_id": user_id, "first_name": first_name})
            return True # Indicates this is a brand new user
        return False # Indicates they already existed

    async def get_all_users(self):
        """Fetches every registered user ID for broadcasting."""
        if self.users_col is None: return []
        cursor = self.users_col.find({})
        return [doc["_id"] async for doc in cursor]

    async def delete_user(self, user_id):
        """Removes users who blocked the bot to keep the DB fast and clean."""
        if self.users_col is None: return
        await self.users_col.delete_one({"_id": user_id})

    async def ban_user(self, user_id):
        """Adds a user to the blacklist."""
        if self.banned_col is None: return
        await self.banned_col.update_one({"_id": user_id}, {"$set": {"_id": user_id}}, upsert=True)

    async def unban_user(self, user_id):
        """Removes a user from the blacklist."""
        if self.banned_col is None: return
        await self.banned_col.delete_one({"_id": user_id})

    async def get_banned_users(self):
        """Fetches all banned IDs into RAM on startup."""
        if self.banned_col is None: return []
        cursor = self.banned_col.find({})
        return [doc["_id"] async for doc in cursor]
    
    # --- 🔗 GROUP CONNECTION SYSTEM ---
    async def add_group(self, group_id, group_title):
        """Silently registers a new group when the bot is added."""
        if self.main_db is None: return False
        groups_col = self.main_db["connected_groups"]
        
        group = await groups_col.find_one({"_id": group_id})
        if not group:
            await groups_col.insert_one({"_id": group_id, "title": group_title})
            return True
        return False

    async def get_all_groups(self):
        """Fetches all connected groups for the stats panel."""
        if self.main_db is None: return []
        groups_col = self.main_db["connected_groups"]
        cursor = groups_col.find({})
        return [doc async for doc in cursor]

    # --- 📁 ADVANCED FILE SYSTEM ---
    async def get_db_size(self, db_instance):
        """Calculates current cluster size in MB."""
        stats = await db_instance.command("dbstats")
        return stats.get("dataSize", 0) / (1024 * 1024)

    async def save_file(self, media):
        """Advanced indexer supporting 2GB+ files and sizes."""
        file_id = getattr(media, "file_id", "")
        file_name = getattr(media, "file_name", "")
        file_size = getattr(media, "file_size", 0) # Grabs exact byte size
        mime_type = getattr(media, "mime_type", "")

        if not file_id or not file_name:
            return False, "Invalid media"

        file_doc = {
            "file_id": file_id,
            "file_name": file_name,
            "file_size": file_size,
            "mime_type": mime_type
        }

        # Check for duplicates across all DBs
        for col in self.file_cols:
            if await col.find_one({"file_name": file_name, "file_size": file_size}):
                return False, "Duplicate"

        # Cascade Logic: Save to the first DB with less than 450MB
        for i, col in enumerate(self.file_cols):
            size = await self.get_db_size(self.dbs[i])
            if size < 450:
                await col.insert_one(file_doc)
                return True, f"Saved to Cluster {i+1}"
        
        return False, "All clusters full"
    
    async def save_files_bulk(self, files_list):
        """High-speed bulk inserter that cross-references ALL clusters for duplicates."""
        if not files_list: 
            return 0, 0
            
        # 1. Find the active cluster (under 450MB)
        active_col = None
        for i, col in enumerate(self.file_cols):
            size = await self.get_db_size(self.dbs[i])
            if size < 450:
                active_col = col
                break
                
        if active_col is None:
            return 0, len(files_list)

        # 2. Extract just the file_ids to quickly check for duplicates
        incoming_ids = [f["file_id"] for f in files_list]
        
        # 3. Ask ALL MongoDB clusters which of these IDs already exist
        existing_ids = set()
        for col in self.file_cols:
            cursor = col.find({"file_id": {"$in": incoming_ids}})
            async for doc in cursor:
                existing_ids.add(doc["file_id"])
        
        # 4. Filter out the duplicates found across any cluster
        new_files = [f for f in files_list if f["file_id"] not in existing_ids]
        duplicates = len(files_list) - len(new_files)
        
        # 5. Bulk execute the remaining fresh files into the active cluster!
        if new_files:
            # ordered=False ensures that if one document fails, the rest still save
            await active_col.insert_many(new_files, ordered=False)
            
        return len(new_files), duplicates

    async def get_search_results(self, query):
        """Strict $and concurrent search across all clusters."""
        results = []
        clean_query = re.sub(r'[^a-zA-Z0-9]', ' ', query.strip())
        words = clean_query.split()
        
        if not words:
            return []

        search_conditions = []
        for word in words:
            # The strict boundary fix so 'eko' DOES NOT match 'gecko' or 'ek'
            strict_regex = f"(?:^|[\\W_]){word}(?:[\\W_]|$)"
            search_conditions.append({"file_name": {"$regex": strict_regex, "$options": "i"}})
            
        mongo_query = {"$and": search_conditions}
        
        for col in self.file_cols:
            cursor = col.find(mongo_query).limit(40)
            async for doc in cursor:
                if not any(r["file_id"] == doc["file_id"] for r in results):
                    results.append(doc)
                if len(results) >= 40: break 
            if len(results) >= 40: break
                
        def natural_sort_key(file_doc):
            return [int(text) if text.isdigit() else text.lower()
                    for text in re.split(r'(\d+)', file_doc['file_name'])]
                    
        results.sort(key=natural_sort_key)
        return results[:40]
                
                
        # 2. --- THE NATURAL SORTER ENGINE ---
        # This magically splits the filename into text and numbers.
        # "S01E02" becomes ['s', 1, 'e', 2] and "S01E10" becomes ['s', 1, 'e', 10].
        # Because 2 is mathematically less than 10, it sorts perfectly!
        def natural_sort_key(file_doc):
            return [int(text) if text.isdigit() else text.lower()
                    for text in re.split(r'(\d+)', file_doc['file_name'])]
                    
        # 3. Sort the results chronologically
        results.sort(key=natural_sort_key)
        
        # Return the perfectly sorted list
        return results[:40]

    async def get_file(self, file_obj_id):
        try:
            obj_id = ObjectId(file_obj_id)
        except:
            return None
            
        for col in self.file_cols:
            file_data = await col.find_one({"_id": obj_id})
            if file_data:
                return file_data
        return None

    # --- 🗑️ DELETION ENGINE ---
    async def delete_file_by_id(self, file_id):
        """Auto-purges a dead Telegram link."""
        for col in self.file_cols:
            result = await col.delete_one({"file_id": file_id})
            if result.deleted_count > 0:
                return True
        return False

    async def purge_cams(self):
        """Mass deletes low-quality theatre recordings."""
        bad_keywords = ["cam", "predvd", "hdcam", "tsrip", "1xbet"]
        regex_pattern = "|".join(bad_keywords)
        deleted_total = 0
        
        for col in self.file_cols:
            result = await col.delete_many({"file_name": {"$regex": regex_pattern, "$options": "i"}})
            deleted_total += result.deleted_count
            
        return deleted_total

    # --- 📊 STATS DASHBOARD ---
    async def get_bot_stats(self):
        """Pulls live metrics for the admin panel."""
        total_users = await self.users_col.count_documents({}) if self.users_col is not None else 0
        total_banned = await self.banned_col.count_documents({}) if self.banned_col is not None else 0
        
        total_files = 0
        db_sizes = []
        
        for i, db_instance in enumerate(self.dbs):
            files_in_db = await self.file_cols[i].count_documents({})
            total_files += files_in_db
            size = await self.get_db_size(db_instance)
            db_sizes.append((i + 1, size))
            
        return total_users, total_banned, total_files, db_sizes

    async def reset_database(self):
        """☢️ WARNING: Drops all collections across all databases."""
        # 1. Drop users and bans
        if self.users_col is not None: await self.users_col.drop()
        if self.banned_col is not None: await self.banned_col.drop()
        
        # 2. Drop all file collections
        for col in self.file_cols:
            await col.drop()
        return True
    
    async def set_index_progress(self, chat_id, msg_id):
        """Saves the current indexing progress to prevent starting over."""
        if self.main_db is None: return
        settings = self.main_db["settings"]
        await settings.update_one(
            {"_id": "index_progress"},
            {"$set": {str(chat_id): msg_id}},
            upsert=True
        )

    async def get_index_progress(self, chat_id):
        """Fetches the last indexed message ID."""
        if self.main_db is None: return 0
        settings = self.main_db["settings"]
        data = await settings.find_one({"_id": "index_progress"})
        if data and str(chat_id) in data:
            return data[str(chat_id)]
        return 0
    # ==========================================
    # ⚙️ ADMIN DASHBOARD SETTINGS
    # ==========================================
    async def get_config(self):
        """Fetches bot settings from MongoDB."""
        if self.config_col is None: return {}
        config = await self.config_col.find_one({"_id": "main_settings"})
        if not config:
            # If settings don't exist yet, create defaults
            default_config = {
                "_id": "main_settings",
                "start_image": "https://telegra.ph/file/default_image.jpg",
                "update_channel_link": "https://t.me/YourUpdateChannel",
                "main_group_link": "https://t.me/YourMainGroup",
                "strict_mode": True 
            }
            await self.config_col.insert_one(default_config)
            return default_config
        return config

    async def update_config(self, key, value):
        """Instantly updates a setting from your Telegram bot menu."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {"_id": "main_settings"}, 
            {"$set": {key: value}}, 
            upsert=True
        )
        return True
    
    # ==========================================
    # ⚙️ ADMIN DASHBOARD SETTINGS
    # ==========================================
    async def get_config(self):
        """Fetches the live bot settings from MongoDB."""
        if self.config_col is None: return {}
        
        config = await self.config_col.find_one({'_id': 'bot_config'})
        if not config:
            import os
            # Fallback to defaults if the database is empty
            config = {
                '_id': 'bot_config',
                'log_channel': int(os.getenv("LOG_CHANNEL_ID", 0) or 0),
                'main_group': os.getenv("MAIN_GROUP_LINK", ""),
                'update_channel': os.getenv("UPDATE_CHANNEL_LINK", ""),
                'start_media': "https://files.catbox.moe/wvdeci.mp4",
                'fsub_channels': [],
                'auto_delete_time': 300
            }
            await self.config_col.insert_one(config)
        return config

    async def update_config(self, key, value):
        """Updates a specific setting in the live database."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {'_id': 'bot_config'}, 
            {'$set': {key: value}}, 
            upsert=True
        )
        return True
    
    async def add_fsub_channel(self, channel_id):
        """Adds a new mandatory channel to the Global FSub list."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {'_id': 'bot_config'}, 
            {'$addToSet': {'fsub_channels': channel_id}}, 
            upsert=True
        )
        return True

    async def remove_fsub_channel(self, channel_id):
        """Removes a channel from the Global FSub list."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {'_id': 'bot_config'}, 
            {'$pull': {'fsub_channels': channel_id}}
        )
        return True
    
    async def add_db_channel(self, channel_id):
        """Adds a new channel to the Auto-Indexer target list."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {'_id': 'bot_config'}, 
            {'$addToSet': {'db_channels': channel_id}}, 
            upsert=True
        )
        return True

    async def remove_db_channel(self, channel_id):
        """Removes a channel from the Auto-Indexer target list."""
        if self.config_col is None: return False
        await self.config_col.update_one(
            {'_id': 'bot_config'}, 
            {'$pull': {'db_channels': channel_id}}
        )
        return True
    
    # ==========================================
    # 🧠 PERSISTENT MEMORY SYSTEM (Fixes RAM loss)
    # ==========================================
    async def save_search(self, session_id, data):
        """Saves a user's search session into MongoDB."""
        if self.cache_col is None: return
        await self.cache_col.update_one({"_id": session_id}, {"$set": data}, upsert=True)

    async def get_search(self, session_id):
        """Retrieves a search session even if the bot restarted."""
        if self.cache_col is None: return None
        return await self.cache_col.find_one({"_id": session_id})
        
    async def clear_old_searches(self, expiry_seconds=600):
        """Deletes searches older than 10 minutes to save space."""
        if self.cache_col is None: return
        import time
        cutoff = time.time() - expiry_seconds
        await self.cache_col.delete_many({"time": {"$lt": cutoff}})

    async def set_index_task(self, chat_id, state):
        """Saves the indexer's play/pause/stop state."""
        if self.indexer_col is None: return
        await self.indexer_col.update_one({"_id": str(chat_id)}, {"$set": {"state": state}}, upsert=True)

    async def get_index_task(self, chat_id):
        """Checks if the indexer should be running."""
        if self.indexer_col is None: return None
        doc = await self.indexer_col.find_one({"_id": str(chat_id)})
        return doc["state"] if doc else None
        
    async def clear_index_task(self, chat_id):
        """Removes the indexer state when finished."""
        if self.indexer_col is None: return
        await self.indexer_col.delete_one({"_id": str(chat_id)})

db = Database()