import os
import re
import time
import random
import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from database.db import db
from tmdb import get_movie_data
from pyrogram.errors import FloodWait

logger = logging.getLogger(__name__)

DATABASE_CHANNEL_ID = int(os.getenv("DATABASE_CHANNEL_ID", 0))
UPDATE_CHANNEL = int(os.getenv("UPDATE_CHANNEL", 0))
MAIN_GROUP_LINK = os.getenv("MAIN_GROUP_LINK", "") 
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", 0))

RECENT_POSTS = {} 
POST_COOLDOWN = 300 

def parse_file_info(filename):
    filename = re.sub(r'\.(mkv|mp4|avi|mov|zip)$', '', filename, flags=re.IGNORECASE)

    year_match = re.search(r'\b(19\d{2}|20\d{2})\b', filename)
    year = year_match.group(1) if year_match else None
    
    qualities = ["4K", "1080p", "720p", "480p", "HDRip", "WEB-DL", "WEBRip", "BluRay", "PreDVD", "CAM", "HD Rip"]
    quality = next((q for q in qualities if re.search(r'\b' + q.replace(' ', r'\s*') + r'\b', filename, re.IGNORECASE)), None)
    if quality and quality.lower() == "hdrip": quality = "HD Rip"
    
    languages = ["Malayalam", "Tamil", "Telugu", "Hindi", "English", "Kannada", "Dual Audio", "Multi Audio"]
    language = next((l for l in languages if re.search(r'\b' + l + r'\b', filename, re.IGNORECASE)), None)
    
    is_series = bool(re.search(r'(S\d+|Season \d+|E\d+|Episode \d+)', filename, re.IGNORECASE))

    clean_title = filename
    if year: clean_title = clean_title.split(year)[0]
    
    clean_title = re.sub(r'[._\-]', ' ', clean_title)
    
    junk = [r'sample\s*of', 'www', '1tamilmv', 'tamilblasters', 'moviezwap', 'tamilyogi', 'life', 'hq', 'esub', 'combined', '10bit', 'org']
    for j in junk:
        clean_title = re.sub(fr'\b{j}\b', '', clean_title, flags=re.IGNORECASE)

    match = re.search(r'\b(19\d{2}|20\d{2}|S\d{1,2}|Season \d+|1080p|720p|480p|4k|2160p)\b', clean_title, re.IGNORECASE)
    if match: clean_title = clean_title[:match.start()]

    clean_title = re.sub(r'\[.*?\]|\(.*?\)', '', clean_title)
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()
    clean_title = re.sub(r'^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$', '', clean_title)

    return clean_title, year, quality, language, is_series

async def auto_post_to_channel(client: Client, filename: str):
    if not UPDATE_CHANNEL: return
    
    clean_title, year, quality, language, is_series = parse_file_info(filename)
    if not clean_title or len(clean_title) < 2: return
    
    current_time = time.time()
    last_posted = RECENT_POSTS.get(clean_title.lower(), 0)
    if current_time - last_posted < POST_COOLDOWN: return
    RECENT_POSTS[clean_title.lower()] = current_time

    tmdb_data = await get_movie_data(clean_title)
    display_title = tmdb_data["title"] if tmdb_data else clean_title.title()
    
    # Inline metadata builder
    metadata = []
    if year: metadata.append(f"<code>{year}</code>")
    if language: metadata.append(f"#{language.replace(' ', '')}")
    if quality: metadata.append(quality)
    
    meta_string = "  •  ".join(metadata)
    
    caption = (
        f"🎬 <b>{display_title}</b>\n"
        f"{meta_string}\n\n"
        f"<blockquote>Tap the button below to get this file instantly.</blockquote>"
    )
    
    safe_title = re.sub(r'[^a-zA-Z0-9\s\-]', ' ', display_title)
    safe_query = re.sub(r'\s+', '_', safe_title.strip())[:45]
    bot_url = f"https://t.me/{client.me.username}?start=search_{safe_query}"
    
    btn_text = "📥 Get Series" if is_series else "📥 Get Movie"
    
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton(btn_text, url=bot_url),
         InlineKeyboardButton("👥 Join Group", url=MAIN_GROUP_LINK)]
    ])
    
    try:
        if tmdb_data and tmdb_data["poster"]:
            await client.send_photo(chat_id=UPDATE_CHANNEL, photo=tmdb_data["poster"], caption=caption, reply_markup=markup, parse_mode=ParseMode.HTML)
        else:
            await client.send_message(chat_id=UPDATE_CHANNEL, text=caption, reply_markup=markup, parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"Failed to auto-post: {e}")

@Client.on_message(filters.channel & (filters.document | filters.video | filters.audio))
async def index_new_files(client: Client, message: Message):
    config = await db.get_config()
    db_channels = config.get("db_channels", [])
    
    env_db = int(os.getenv("DATABASE_CHANNEL_ID", 0) or 0)
    if env_db and env_db not in db_channels:
        db_channels.append(env_db)

    if message.chat.id not in db_channels:
        return

    media = message.document or message.video or message.audio
    if not media or not hasattr(media, "file_name") or not media.file_name:
        return

    success, return_msg = await db.save_file(media)
    
    if LOG_CHANNEL_ID:
        try:
            await client.send_message(
                LOG_CHANNEL_ID,
                f"✅ **Successfully Indexed**\n\n"
                f"🎬 **File:** `{media.file_name}`\n"
                f"💿 **Size:** `{media.file_size / (1024 * 1024):.2f} MB`"
            )
        except Exception: pass
    
    async def delayed_post():
        await asyncio.sleep(random.uniform(2.0, 5.0))
        await auto_post_to_channel(client, media.file_name)
        
    asyncio.create_task(delayed_post())