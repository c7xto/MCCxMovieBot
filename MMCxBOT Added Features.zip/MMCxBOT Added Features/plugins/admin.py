import os
import asyncio
import logging
from pyrogram import ContinuePropagation
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import db

logger = logging.getLogger(__name__)

ADMIN_ID = int(os.getenv("ADMIN_ID", 0))
ADMIN_STATE = {} # State dictionary to remember what the admin is editing

async def get_admin_menu_data():
    """Helper function to fetch live config and generate the dynamic menu."""
    config = await db.get_config()
    
    # We use your custom stats function for the basic user count
    total_users, _, total_files, _ = await db.get_bot_stats()

    # ============================================================
    # ✨ UX ENHANCEMENT #8 — Live Status Indicators in Admin Panel
    # ============================================================
    fsub_count = len(config.get('fsub_channels', []))
    fsub_status = f"✅ Active ({fsub_count} ch)" if fsub_count > 0 else "⚫ Disabled"
    log_status = "✅ Set" if config.get('log_channel') else "❌ Missing"
    group_status = "✅ Set" if config.get('main_group') else "❌ Missing"
    update_status = "✅ Set" if config.get('update_channel') else "❌ Missing"

    text = (
        f"╔══ 🛠 **MCCxBot Control Panel** ══╗\n\n"
        f"📊 **Live Stats:**\n"
        f"┣ 👤 Users: `{total_users}`\n"
        f"┣ 📁 Files: `{total_files}`\n"
        f"┣ 📡 Log Channel: {log_status}\n"
        f"┗ 🔐 FSub: {fsub_status}\n\n"
        f"⚙️ **Core Settings:**\n"
        f"┣ 🔸 Log Channel: `{config.get('log_channel', 'Not Set')}`\n"
        f"┣ 🔹 Main Group: {group_status}\n"
        f"┗ 🔹 Update Channel: {update_status}\n\n"
        f"╚══ _Select a module below_ ══╝"
    )

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Deep Stats & Analytics", callback_data="admin_stats")],
        [InlineKeyboardButton("📚 Manage Database Channels", callback_data="db_chan_menu")],
        [InlineKeyboardButton("🔐 Manage FSub Channels", callback_data="fsub_menu")],
        [InlineKeyboardButton("⚙️ Change Main Group Link", callback_data="edit_maingroup")],
        [InlineKeyboardButton("⚙️ Change Update Link", callback_data="edit_update")],
        [InlineKeyboardButton("🖼 Change Welcome Media", callback_data="edit_media")],
        [InlineKeyboardButton("📝 Edit Welcome Text", callback_data="edit_welcometext")], # <-- ADDED THIS
        [InlineKeyboardButton("❌ Close Panel", callback_data="close_data")]
    ])
    return text, markup


# --- DASHBOARD UI ---
@Client.on_message(filters.command("admin") & filters.private & filters.user(ADMIN_ID))
async def admin_panel(client: Client, message: Message):
    text, markup = await get_admin_menu_data()
    await message.reply_text(text=text, reply_markup=markup, quote=True, disable_web_page_preview=True)

@Client.on_callback_query(filters.regex(r"^back_to_admin$") & filters.user(ADMIN_ID))
async def back_to_admin(client: Client, callback: CallbackQuery):
    text, markup = await get_admin_menu_data()
    await callback.message.edit_text(text=text, reply_markup=markup, disable_web_page_preview=True)

# --- 1. YOUR EXISTING STATS TRACKER ---
@Client.on_callback_query(filters.regex(r"^admin_stats$") & filters.user(ADMIN_ID))
async def show_stats(client: Client, callback: CallbackQuery):
    await callback.message.edit_text("⏳ **Calculating live database metrics...**")
    
    total_users, total_banned, total_files, db_sizes = await db.get_bot_stats()
    
    stats_text = (
        f"📊 **MCCxBot Live Analytics**\n\n"
        f"👥 **Total Verified Users:** `{total_users}`\n"
        f"🚫 **Banned Users:** `{total_banned}`\n"
        f"📁 **Total Indexed Files:** `{total_files}`\n\n"
        f"💾 **Storage Overview (MongoDB Clusters):**\n"
    )
    
    for db_num, size in db_sizes:
        # Visual fill bar per cluster
        fill = int((size / 512) * 10)
        bar = "█" * fill + "░" * (10 - fill)
        stats_text += f"├ Cluster {db_num}: [{bar}] `{size:.2f} MB` / 512 MB\n"
        
    markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back to Menu", callback_data="back_to_admin")]])
    await callback.message.edit_text(stats_text, reply_markup=markup)


# --- 2. THE NEW DYNAMIC CONFIG HANDLERS ---
@Client.on_callback_query(filters.regex(r"^edit_") & filters.user(ADMIN_ID))
async def handle_edit_buttons(client: Client, callback: CallbackQuery):
    action = callback.data.split("_")[1]
    ADMIN_STATE[callback.from_user.id] = action
    
    if action == "maingroup":
        prompt = "🔗 **Send me the new Main Group Link** (Public or Private).\n*Type /cancel to abort.*"
    elif action == "update":
        prompt = "🔗 **Send me the new Updates Channel Link** (Public or Private).\n*Type /cancel to abort.*"
    elif action == "adddb":
        prompt = "➕ **Send me the Channel ID** (e.g., `-100123...`) to add to the Auto-Indexer.\n*Type /cancel to abort.*"
    elif action == "remdb":
        prompt = "➖ **Send me the Channel ID** to remove from the Auto-Indexer.\n*Type /cancel to abort.*"
    elif action == "media":
        prompt = "🖼 **Send me the new Catbox Link** for your Welcome Media (.mp4, .gif, or image).\n*Type /cancel to abort.*"
    elif action == "addfsub":
        prompt = "➕ **Send me the Channel ID (e.g., -100123...) or Username (e.g., @channel)** to add to FSub.\n*Make sure the bot is an Admin there! Type /cancel to abort.*"
    elif action == "remfsub":
        prompt = "➖ **Send me the Channel ID or Username** to remove from FSub.\n*Type /cancel to abort.*"
    elif action == "media":
        prompt = "🖼 **Send me the new Catbox Link** for your Welcome Media (.mp4, .gif, or image).\n*Type /cancel to abort.*"
    elif action == "welcometext": # <-- ADDED THIS BLOCK
        prompt = (
            "📝 **Send me the new Welcome Message.**\n\n"
            "**Tip:** You can use standard Telegram HTML tags (like `<b>`, `<i>`, `<blockquote>`).\n"
            "Type `{mention}` exactly like that wherever you want the user's name to appear!\n\n"
            "*Type /cancel to abort.*"
        )
    else:
        return
        
    await callback.message.reply_text(prompt)
    await callback.answer()

# --- THE FSUB MANAGER MENU ---
@Client.on_callback_query(filters.regex(r"^fsub_menu$") & filters.user(ADMIN_ID))
async def show_fsub_menu(client: Client, callback: CallbackQuery):
    config = await db.get_config()
    channels = config.get("fsub_channels", [])
    
    text = "🔐 **Global FSub (Force Subscribe) Manager**\n\n"
    if not channels:
        text += "🔸 **Status:** ⚫ Disabled (No channels set).\n"
    else:
        text += f"🔸 **Status:** ✅ Active — `{len(channels)}` channel(s) enforced\n\n"
        text += "📋 **Currently Enforced Channels:**\n"
        for i, ch in enumerate(channels, 1):
            text += f" {i}. `{ch}`\n"
            
    text += "\n*Users must join ALL listed channels to use the bot in PM.*"
    
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add Channel", callback_data="edit_addfsub"),
         InlineKeyboardButton("➖ Remove Channel", callback_data="edit_remfsub")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_admin")]
    ])
    await callback.message.edit_text(text, reply_markup=markup)

# --- THE DATABASE CHANNELS MANAGER ---
@Client.on_callback_query(filters.regex(r"^db_chan_menu$") & filters.user(ADMIN_ID))
async def show_db_chan_menu(client: Client, callback: CallbackQuery):
    config = await db.get_config()
    channels = config.get("db_channels", [])
    
    text = "📚 **Auto-Indexer Channels**\n\nThe bot will automatically absorb files uploaded to these channels:\n\n"
    if not channels:
        text += "🔸 **Status:** No extra channels set (Only checking .env).\n"
    else:
        for i, ch in enumerate(channels, 1):
            text += f" {i}. `{ch}`\n"
            
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add DB Channel", callback_data="edit_adddb"),
         InlineKeyboardButton("➖ Remove DB", callback_data="edit_remdb")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_admin")]
    ])
    await callback.message.edit_text(text, reply_markup=markup)


@Client.on_message(filters.private & filters.text & filters.user(ADMIN_ID) & ~filters.command(["start", "admin", "ban", "unban", "purge_cams", "reset_db"]))
async def catch_admin_input(client: Client, message: Message):
    admin_id = message.from_user.id
    state = ADMIN_STATE.get(admin_id)
    
    if not state:
        # MAGIC FIX: Tells the bot "I don't need this, pass it to the search engine!"
        raise ContinuePropagation 

    if message.text.lower() == "/cancel":
        ADMIN_STATE.pop(admin_id, None)
        return await message.reply_text("🚫 **Action Cancelled.**")

    # Update Database based on state
    if state == "maingroup":
        await db.update_config("main_group", message.text.strip())
        await message.reply_text("✅ **Main Group Link Successfully Updated!**")
    elif state == "update":
        await db.update_config("update_channel", message.text.strip())
        await message.reply_text("✅ **Updates Channel Link Successfully Updated!**")
    elif state == "adddb":
        try:
            ch_val = int(message.text.strip())
            await client.get_chat(ch_val) # Verify we have access
            await db.add_db_channel(ch_val)
            await message.reply_text(f"✅ **Database Channel `{ch_val}` Added!**\nAny movie uploaded there will now be auto-indexed.")
        except Exception as e:
            await message.reply_text(f"❌ **Failed!** Make sure I am an Admin in that channel.\nError: `{e}`")
    elif state == "remdb":
        ch_val = int(message.text.strip())
        await db.remove_db_channel(ch_val)
        await message.reply_text(f"✅ **Channel `{ch_val}` Removed.**")
    elif state == "media":
        await db.update_config("start_media", message.text.strip())
        await message.reply_text("✅ **Welcome Media Successfully Updated!**")
    elif state == "media":
        await db.update_config("start_media", message.text.strip())
        await message.reply_text("✅ **Welcome Media Successfully Updated!**")
    elif state == "welcometext":
        # We simply save exactly what you type!
        await db.update_config("welcome_text", message.text)
        await message.reply_text("✅ **Welcome Text Successfully Updated!**\n\nGo type /start to see it live.")
    elif state == "addfsub":
        try:
            # Convert to integer if it's an ID (like -100xxx), otherwise keep as string (like @channel)
            ch_val = int(message.text.strip()) if message.text.strip().lstrip('-').isdigit() else message.text.strip()
            # Verify the bot is actually an admin in this channel before adding it!
            await client.get_chat_member(ch_val, client.me.id)
            await db.add_fsub_channel(ch_val)
            await message.reply_text(f"✅ **Channel {ch_val} Successfully Added to FSub!**")
        except Exception as e:
            await message.reply_text(f"❌ **Failed to add channel!**\nMake sure the bot is an Admin in that channel first.\nError: `{e}`")
    elif state == "remfsub":
        ch_val = int(message.text.strip()) if message.text.strip().lstrip('-').isdigit() else message.text.strip()
        await db.remove_fsub_channel(ch_val)
        await message.reply_text(f"✅ **Channel {ch_val} Successfully Removed from FSub!**")

    ADMIN_STATE.pop(admin_id, None)


# --- 3. YOUR EXISTING SECURITY COMMANDS ---
@Client.on_message(filters.command("ban") & filters.private & filters.user(ADMIN_ID))
async def ban_user_cmd(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.reply_text("⚠️ **Usage:** `/ban [user_id]`")
    user_id = int(message.command[1])
    await db.ban_user(user_id)
    await message.reply_text(f"✅ **User `{user_id}` has been permanently banned.**")

@Client.on_message(filters.command("unban") & filters.private & filters.user(ADMIN_ID))
async def unban_user_cmd(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.reply_text("⚠️ **Usage:** `/unban [user_id]`")
    user_id = int(message.command[1])
    await db.unban_user(user_id)
    await message.reply_text(f"✅ **User `{user_id}` has been unbanned.**")


# --- 4. YOUR EXISTING DELETION COMMANDS ---
@Client.on_message(filters.command("purge_cams") & filters.private & filters.user(ADMIN_ID))
async def purge_cams_cmd(client: Client, message: Message):
    status = await message.reply_text("⏳ **Scanning all 5 clusters for CAM/PreDVD rips...**")
    deleted_count = await db.purge_cams()
    await status.edit_text(f"🗑️ **Purge Complete!**\n\nDeleted `{deleted_count}` low-quality theatre rips from the database.")

@Client.on_message(filters.command("reset_db") & filters.private & filters.user(ADMIN_ID))
async def reset_db_cmd(client: Client, message: Message):
    await message.reply_text(
        "⚠️ **WARNING: NUCLEAR OPTION** ⚠️\n\n"
        "Are you absolutely sure you want to completely wipe ALL files, users, and bans across all 5 clusters?\n\n"
        "To confirm, reply to this message with: `/confirm_reset`",
        quote=True
    )

@Client.on_message(filters.command("confirm_reset") & filters.private & filters.user(ADMIN_ID))
async def confirm_reset_cmd(client: Client, message: Message):
    status = await message.reply_text("☢️ **Nuking the database...**")
    await db.reset_database()
    await status.edit_text("✅ **Database has been completely wiped.** You now have a clean slate.")

@Client.on_callback_query(filters.regex(r"^close_data$") & filters.user(ADMIN_ID))
async def close_callback(client: Client, callback: CallbackQuery):
    await callback.message.delete()
