import os
import re
import time
import random
import string
import asyncio
import logging
from urllib.parse import quote
from pyrogram.errors import MessageNotModified, FloodWait
from pyrogram import Client, filters
from pyrogram.enums import ParseMode
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import db
from utils import is_subscribed, send_fsub_message
from tmdb import get_movie_data

logger = logging.getLogger(__name__)

MISSED_CACHE = set()
IGNORE_WORDS = {"hi", "hello", "bro", "pls", "plz", "bot", "help", "admin", "sir"}

# --- RATE LIMITER ---
USER_SEARCH_COOLDOWN = {}
COOLDOWN_TIME = 2

async def send_smart_log(client, text):
    try:
        config = await db.get_config()
        log_chat = config.get("log_channel", 0)
        if log_chat:
            await client.send_message(log_chat, text)
    except FloodWait:
        pass
    except Exception:
        pass

LANGUAGES = ["Malayalam", "Tamil", "Telugu", "Hindi", "English", "Kannada", "Dual Audio", "Multi Audio"]
QUALITIES = ["4K", "1080p", "720p", "480p", "HDRip", "WEB-DL", "WEBRip", "BluRay", "PreDVD", "CAM", "HD Rip"]

LANG_EMOJI = {
    "Malayalam": "🌴", "Tamil": "🎭", "Telugu": "⭐",
    "Hindi": "🇮🇳", "English": "🌍", "Kannada": "🏵",
    "Dual Audio": "🎧", "Multi Audio": "🎵", "Other": "🌐"
}

def clean_query(query):
    stop_words = [r'\bplease\b', r'\bsend\b', r'\bme\b', r'\bthe\b', r'\bmovie\b', r'\bseries\b', r'\bhd\b', r'\bprint\b', r'\bdownload\b', r'\blink\b', r'\bbro\b', r'\bcan\b', r'\byou\b', r'\bprovide\b', r'\bi\b', r'\bneed\b', r'\bwant\b']
    query_clean = query.lower()
    for word in stop_words:
        query_clean = re.sub(word, '', query_clean, flags=re.IGNORECASE)
    return re.sub(r'\s+', ' ', query_clean).strip()

def extract_attributes(filename):
    lang = next((l for l in LANGUAGES if re.search(r'\b' + l + r'\b', filename, re.IGNORECASE)), "Other")
    qual = next((q for q in QUALITIES if re.search(r'\b' + q.replace(' ', r'\s*') + r'\b', filename, re.IGNORECASE)), "Other")
    if qual.lower() == "hdrip": qual = "HD Rip"
    return lang, qual

@Client.on_message(filters.text & filters.private & ~filters.command(["start", "help", "about", "admin", "broadcast", "ban", "unban", "purge_cams", "reset_db"]))
async def auto_filter(client: Client, message: Message, manual_query=None):
    if not await is_subscribed(client, message):
        await send_fsub_message(message)
        return

    # Anti-Spam Rate Limiter
    user_id = message.from_user.id
    current_time = time.time()
    if user_id in USER_SEARCH_COOLDOWN:
        time_passed = current_time - USER_SEARCH_COOLDOWN[user_id]
        if time_passed < COOLDOWN_TIME:
            warning = await message.reply_text(
                f"⏳ **Anti-Spam:** Please wait `{int(COOLDOWN_TIME - time_passed) + 1}s` before searching again.", 
                quote=True
            )
            await asyncio.sleep(2)
            try:
                await warning.delete()
            except:
                pass
            return
            
    USER_SEARCH_COOLDOWN[user_id] = current_time
    start_time = time.time()

    if manual_query:
        query = manual_query
    else:
        original_text = message.text
        query = clean_query(original_text)
        clean_content = original_text.lower().strip()

        if len(clean_content) < 3 or clean_content in IGNORE_WORDS:
            config = await db.get_config()
            main_group = config.get("main_group", "")
            await message.reply_text(
                f"<b>🙋 ʜᴇʏ {message.from_user.first_name} 😍 ,\n\n𝒀𝒐𝒖 𝒄𝒂𝒏 𝒔𝒆𝒂𝒓𝒄ʜ 𝒇𝒐𝒓 𝒎𝒐𝒗𝒊𝒆𝒔 𝒐𝒏𝒍𝒚 𝒐𝒏 𝒐𝒖𝒓 𝑴𝒐𝒗𝒊𝒆 𝑮𝒓𝒐𝒖𝒑.</b>",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📝 ʀᴇǫᴜᴇsᴛ ʜᴇʀᴇ ", url=main_group)]] if main_group else []),
                quote=True,
                parse_mode=ParseMode.HTML
            )
            return

    results = await db.get_search_results(query)

    if not results:
        google_url = f"https://www.google.com/search?q={quote(query)}"
        safe_query = query[:40] 
        
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔍 Check Spelling on Google", url=google_url)],
            [InlineKeyboardButton("📝 Request This Movie", callback_data=f"reqmovie#{safe_query}")],
            [InlineKeyboardButton("🏠 Home", callback_data="start_home")]
        ])
        
        text = (
            f"🔍 <b>No results for</b> <code>{query}</code>\n\n"
            f"<blockquote>This title isn't in our database yet.\n"
            f"Check the spelling or tap Request below.</blockquote>"
        )
        return await message.reply_text(text, reply_markup=markup, disable_web_page_preview=True, parse_mode=ParseMode.HTML)

    time_taken = time.time() - start_time
    await db.clear_old_searches()
    session_id = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    
    session_data = {
        "results": results, 
        "query": query, 
        "speed": f"{time_taken:.3f}s",
        "time": time.time()
    }
    await db.save_search(session_id, session_data)

    status_msg = await message.reply_text("🔍", quote=True)
    await route_menu(client, status_msg, session_id, "ALL", "ALL", 0)
    
    await asyncio.sleep(300)
    try:
        await status_msg.delete()
        if not manual_query:
            await message.delete()
    except:
        pass

async def route_menu(client, message, session_id, lang, qual, page):
    data = await db.get_search(session_id)
    if not data:
        return await message.edit_text("⚠️ **Search Session Expired.** Please search for the movie again.")

    all_files = data["results"]
    tmdb = data.get("tmdb")

    filtered_files = []
    for f in all_files:
        f_lang, f_qual = extract_attributes(f["file_name"])
        if lang not in ["ALL", "MIXED"] and f_lang != lang: continue
        if qual not in ["ALL", "MIXED"] and f_qual != qual: continue
        filtered_files.append((f, f_lang, f_qual))

    available_langs = set(f[1] for f in filtered_files)
    available_quals = set(f[2] for f in filtered_files)

    title_display = tmdb['title'] if tmdb else data['query']
    title_display = title_display.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    
    caption = (
        f"🎬 <b>{title_display.upper()}</b>\n"
        f"<blockquote>📦 {len(filtered_files)} files found  •  ⚡ {data['speed']}\n"
        f"🗑 Auto-deletes in 5 mins</blockquote>\n\n"
    )

    buttons = [] 

    if lang == "ALL" and len(available_langs) > 1:
        caption += "🌐 <b>Step 1 of 2</b> — Choose your language:"
        lang_counts = {}
        for f, f_lang, _ in filtered_files:
            lang_counts[f_lang] = lang_counts.get(f_lang, 0) + 1

        row = []
        for l in sorted(available_langs):
            count = lang_counts.get(l, 0)
            l_emoji = LANG_EMOJI.get(l, "🔊")
            row.append(InlineKeyboardButton(f"{l_emoji} {l} ({count})", callback_data=f"lang#{session_id}#{l}"))
            if len(row) == 2:
                buttons.append(row)
                row = []
        if row: buttons.append(row)
        buttons.append([InlineKeyboardButton("🌍 Show All Languages", callback_data=f"lang#{session_id}#MIXED")])
        buttons.append([InlineKeyboardButton("🏠 Home", callback_data="start_home")])

    elif qual == "ALL" and len(available_quals) > 1:
        display_lang = lang if lang not in ["ALL", "MIXED"] else "All Languages"
        caption += f"💿 <b>Step 2 of 2</b> — Choose quality for <b>{display_lang}</b>:"
        qual_counts = {}
        for f, _, f_qual in filtered_files:
            qual_counts[f_qual] = qual_counts.get(f_qual, 0) + 1

        row = []
        for q in sorted(available_quals):
            count = qual_counts.get(q, 0)
            row.append(InlineKeyboardButton(f"{q} ({count})", callback_data=f"qual#{session_id}#{lang}#{q}"))
            if len(row) == 2:
                buttons.append(row)
                row = []
        if row: buttons.append(row)
        buttons.append([InlineKeyboardButton("🎞 Show All Qualities", callback_data=f"qual#{session_id}#{lang}#MIXED")])
        buttons.append([
            InlineKeyboardButton("◀️ Back", callback_data=f"lang#{session_id}#ALL"),
            InlineKeyboardButton("🏠 Home", callback_data="start_home")
        ])

    else:
        lang_tag = f"  {LANG_EMOJI.get(lang, '🔊')} {lang}" if lang not in ["ALL", "MIXED"] else ""
        qual_tag = f"  {qual}" if qual not in ["ALL", "MIXED"] else "" # Emojis removed from quality tag
        caption += f"📂 <b>{len(filtered_files)} files</b>{lang_tag}{qual_tag}\n👇 Tap a file to receive it in your PM:"
        
        per_page = 10
        total_pages = (len(filtered_files) + per_page - 1) // per_page
        start_idx = page * per_page
        end_idx = start_idx + per_page
        page_files = filtered_files[start_idx:end_idx]

        for f, f_lang, f_qual in page_files:
            size_mb = f.get('file_size', 0) / (1024 * 1024)
            size_str = f"{size_mb / 1024:.2f} GB" if size_mb >= 1024 else f"{size_mb:.0f} MB"
            
            display_name = f['file_name']
            if lang not in ["ALL", "MIXED"]: display_name = re.sub(rf'\b{lang}\b', '', display_name, flags=re.IGNORECASE)
            if qual not in ["ALL", "MIXED"]: display_name = re.sub(rf'\b{qual}\b', '', display_name, flags=re.IGNORECASE)
            display_name = re.sub(r'\s+', ' ', display_name).strip(" -_")
            
            # Put the size back on the left side!
            btn_text = f"[{size_str}] {display_name[:28]}"
            buttons.append([InlineKeyboardButton(btn_text, callback_data=f"sendfile#{f['_id']}")])

        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"page#{session_id}#{lang}#{qual}#{page-1}"))
        if total_pages > 1:
            nav_buttons.append(InlineKeyboardButton(f"📄 {page+1}/{total_pages}", callback_data="ignore"))
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton("Next ➡️", callback_data=f"page#{session_id}#{lang}#{qual}#{page+1}"))
        
        if nav_buttons: buttons.append(nav_buttons)
        buttons.append([
            InlineKeyboardButton("◀️ Back", callback_data=f"lang#{session_id}#ALL"),
            InlineKeyboardButton("🏠 Home", callback_data="start_home")
        ])

    markup = InlineKeyboardMarkup(buttons)
    try:
        await message.edit_text(text=caption, reply_markup=markup, parse_mode=ParseMode.HTML)
    except MessageNotModified:
        pass
    except Exception as e:
        logger.error(f"UI Route Error: {e}")

@Client.on_callback_query(filters.regex(r"^lang#"))
async def handle_language(client: Client, callback: CallbackQuery):
    _, session_id, lang = callback.data.split("#")
    await route_menu(client, callback.message, session_id, lang, "ALL", 0)
    await callback.answer()

@Client.on_callback_query(filters.regex(r"^qual#"))
async def handle_quality(client: Client, callback: CallbackQuery):
    _, session_id, lang, qual = callback.data.split("#")
    await route_menu(client, callback.message, session_id, lang, qual, 0)
    await callback.answer()

@Client.on_callback_query(filters.regex(r"^page#"))
async def handle_pagination(client: Client, callback: CallbackQuery):
    _, session_id, lang, qual, page = callback.data.split("#")
    await route_menu(client, callback.message, session_id, lang, qual, int(page))
    await callback.answer()

@Client.on_callback_query(filters.regex(r"^ignore$"))
async def handle_ignore(client: Client, callback: CallbackQuery):
    await callback.answer()

@Client.on_callback_query(filters.regex(r"^sendfile#"))
async def send_movie_file(client: Client, callback: CallbackQuery):
    _, file_obj_id = callback.data.split("#")
    file_data = await db.get_file(file_obj_id)
    
    if not file_data:
        return await callback.answer("⚠️ This file is no longer available in the database.", show_alert=True)
        
    await callback.answer("📤 Sending file... Please wait!", show_alert=False)
    
    sent_message = await client.send_cached_media(
        chat_id=callback.message.chat.id,
        file_id=file_data["file_id"],
        caption=(
            f"🍿 <b>{file_data['file_name']}</b>\n\n"
            f"<blockquote>⏳ Auto-deletes in <b>5 minutes</b> — save it before then!</blockquote>\n\n"
            f"📢 More movies → @{client.me.username}"
        )
    )
    
    await asyncio.sleep(240)
    try:
        await sent_message.edit_caption(
            caption=(
                f"🍿 <b>{file_data['file_name']}</b>\n\n"
                f"<blockquote>⚠️ Deleting in <b>1 minute</b> — save it now!</blockquote>\n\n"
                f"📢 More movies → @{client.me.username}"
            ),
            parse_mode=ParseMode.HTML
        )
    except Exception:
        pass

    await asyncio.sleep(60)
    try:
        await sent_message.delete()
    except Exception:
        pass

@Client.on_callback_query(filters.regex(r"^check_fsub_status$"))
async def check_fsub_callback(client: Client, callback: CallbackQuery):
    is_subbed = await is_subscribed(client, callback)
    if is_subbed:
        await callback.message.delete()
        await callback.message.reply_text("✅ **Verification Successful!**\n\nYou can now type a movie name to search.", quote=True)
    else:
        await callback.answer("❌ You haven't joined the channels yet! Please join them and try again.", show_alert=True)

@Client.on_message(filters.text & filters.group)
async def group_filter_handler(client: Client, message: Message):
    start_time = time.time()
    query = clean_query(message.text)
    if len(query) < 3 or query.lower() in IGNORE_WORDS: return

    results = await db.get_search_results(query)
    if results:
        time_taken = time.time() - start_time
        bot_username = client.me.username
        pm_link = f"https://t.me/{bot_username}?start=search_{query.replace(' ', '_')}"
        
        receipt_text = (
            f"🎬 <b>{query.title()}</b>  —  {len(results)} files found\n"
            f"<blockquote>⚡ Fetched in {time_taken:.3f}s\n"
            f"🗑 This message clears in 60s</blockquote>"
        )
        
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("📥  Get Files in PM", url=pm_link)
        ]])

        receipt = await message.reply_text(text=receipt_text, reply_markup=markup, parse_mode=ParseMode.HTML)

        await asyncio.sleep(60)
        try:
            await receipt.delete()
            await message.delete() 
        except:
            pass

@Client.on_callback_query(filters.regex(r"^reqmovie#"))
async def handle_movie_request(client: Client, callback: CallbackQuery):
    _, movie_name = callback.data.split("#")
    
    config = await db.get_config()
    log_channel = config.get("log_channel", 0)
    
    if not log_channel:
        return await callback.answer("⚠️ Request system is currently offline. Admins need to set a Log Channel.", show_alert=True)
        
    request_text = (
        f"📝 **New Movie Request**\n\n"
        f"🎬 **Movie:** `{movie_name}`\n"
        f"👤 **From:** {callback.from_user.mention} (`{callback.from_user.id}`)\n\n"
        f"*(Admins: Upload this movie to the database channel to fulfill the request!)*"
    )
    
    try:
        await client.send_message(log_channel, text=request_text)
        await callback.answer(f"✅ Your request for '{movie_name}' has been sent to the admins!", show_alert=True)
        await callback.message.edit_text(
            f"✅ **Request Sent!**\n\n"
            f"We have notified the admins to upload: `{movie_name}`\n"
            f"_Most requests are fulfilled within 24 hours. Check the updates channel!_",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Home", callback_data="start_home")]])
        )
    except Exception as e:
        await callback.answer("❌ Failed to send request.", show_alert=True)
        logger.error(f"Request Error: {e}")