import os
import time
import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait, InputUserDeactivated, UserIsBlocked
from database.db import db

logger = logging.getLogger(__name__)
ADMIN_ID = int(os.getenv("ADMIN_ID", 0))

@Client.on_message(filters.command("broadcast") & filters.private & filters.user(ADMIN_ID))
async def broadcast_handler(client: Client, message: Message):
    # 1. CHECK IF ADMIN REPLIED TO A MESSAGE
    if not message.reply_to_message:
        return await message.reply_text(
            "⚠️ **Usage:** Reply to any message (text, photo, video) with `/broadcast`\n\n"
            "**Optional Flags:**\n"
            "├ `-pin` : Silently pins the message for the user\n"
            "└ `-del` : Auto-deletes the broadcast after 24 hours\n\n"
            "*Example:* `/broadcast -pin -del`",
            quote=True
        )
    
    # 2. PARSE THE FLAGS
    flags = message.text.lower()
    do_pin = "-pin" in flags
    do_del = "-del" in flags

    # 3. GET ALL USERS FROM DATABASE
    users = await db.get_all_users()
    if not users:
        return await message.reply_text("❌ No users found in the database.")
        
    status_msg = await message.reply_text(f"⏳ **Broadcasting to {len(users)} users...**\n_(This might take a while)_")
    
    sent, failed, blocked = 0, 0, 0
    
    # 4. EXECUTE BROADCAST
    for user_id in users:
        try:
            # We use .copy() so it looks like a clean message, not a "forward"
            b_msg = await message.reply_to_message.copy(chat_id=user_id)
            sent += 1
            
            # --- PIN FEATURE ---
            if do_pin:
                try:
                    await b_msg.pin(both_sides=True, disable_notification=True)
                except Exception:
                    pass
                    
            # --- AUTO-DELETE FEATURE ---
            if do_del:
                # Schedule deletion in the background for 24 hours (86400 seconds)
                async def auto_delete_broadcast(msg, delay=86400):
                    await asyncio.sleep(delay)
                    try:
                        await msg.delete()
                    except Exception:
                        pass
                asyncio.create_task(auto_delete_broadcast(b_msg, 86400))
                
        except FloodWait as e:
            # If Telegram limits us, sleep and try again
            await asyncio.sleep(e.value)
            try:
                b_msg = await message.reply_to_message.copy(chat_id=user_id)
                sent += 1
            except Exception:
                failed += 1
                
        except (InputUserDeactivated, UserIsBlocked):
            # THE CLEANUP ENGINE: If the user blocked the bot, delete them from the database!
            blocked += 1
            await db.delete_user(user_id) 
            
        except Exception as e:
            failed += 1
            
        # Mandatory anti-spam sleep to protect the bot's API token
        await asyncio.sleep(0.05) 
        
    # 5. FINAL RECEIPT
    await status_msg.edit_text(
        f"✅ **Broadcast Complete!**\n\n"
        f"📢 **Total Sent:** `{sent}`\n"
        f"🚫 **Blocked/Deleted:** `{blocked}` _(Removed from DB)_\n"
        f"❌ **Failed:** `{failed}`\n"
        f"📌 **Pinned:** `{'Yes' if do_pin else 'No'}`\n"
        f"🗑️ **Auto-Delete (24h):** `{'Yes' if do_del else 'No'}`"
    )